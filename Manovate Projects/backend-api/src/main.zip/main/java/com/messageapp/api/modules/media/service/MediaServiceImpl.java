package com.messageapp.api.modules.media.service;

import com.messageapp.api.common.exceptions.ApiException;
import com.messageapp.api.modules.media.dto.MediaUploadResponseDto;
import com.messageapp.api.modules.media.model.MediaFile;
import com.messageapp.api.modules.media.repository.MediaRepository;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.*;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;

@Service
public class MediaServiceImpl implements MediaService {

    private final MediaRepository mediaRepository;
    private final Path uploadDir = Paths.get("uploads");

    public MediaServiceImpl(MediaRepository mediaRepository) throws IOException {
        this.mediaRepository = mediaRepository;
        Files.createDirectories(uploadDir);
    }

    @Override
    public MediaUploadResponseDto upload(MultipartFile file, Long userId) throws Throwable {

        validateFile(file);

        String storedFileName =
                UUID.randomUUID() + "_" + file.getOriginalFilename();

        Path targetPath = uploadDir.resolve(storedFileName);
        Files.copy(file.getInputStream(), targetPath, StandardCopyOption.REPLACE_EXISTING);

        MediaFile media = new MediaFile();
        media.setFileName(storedFileName);
        media.setFileType(file.getContentType());
        media.setFileSize(file.getSize());
        media.setUploadedBy(userId);
        media.setUploadedAt(LocalDateTime.now());

        mediaRepository.save(media);

        media.setFileUrl("/api/media/" + media.getId());
        mediaRepository.save(media);

        return new MediaUploadResponseDto(
                media.getId(),
                media.getFileUrl(),
                media.getFileType()
        );
    }

    private void validateFile(MultipartFile file) throws Throwable {

        if (file.isEmpty()) {
            throw new Throwable("FILE_EMPTY");
        }

        String type = file.getContentType();
        if (type == null ||
                (!type.startsWith("image") && !type.startsWith("video"))) {
            throw new Throwable("INVALID_FILE_TYPE");
        }

        if (file.getSize() > 10 * 1024 * 1024) {
            throw new Throwable("FILE_TOO_LARGE");
        }

        String name = file.getOriginalFilename();
        if (name == null || !name.contains(".")) {
            throw new Throwable("INVALID_FILE_NAME");
        }

        String ext = name.substring(name.lastIndexOf('.') + 1).toLowerCase();
        List<String> allowed = List.of("jpg", "jpeg", "png", "mp4", "mov");

        if (!allowed.contains(ext)) {
            throw new Throwable("INVALID_FILE_EXTENSION");
        }
    }
}
