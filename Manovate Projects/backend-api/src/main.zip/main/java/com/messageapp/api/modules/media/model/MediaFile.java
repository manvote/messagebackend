package com.messageapp.api.modules.media.model;

import jakarta.persistence.*;
import org.jspecify.annotations.Nullable;

import java.time.LocalDateTime;

@Entity
@Table(name = "media_files")
public class MediaFile {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "file_name", nullable = false)
    private String fileName;

    @Column(name = "file_type")
    private String fileType;

    @Column(name = "file_size")
    private Long fileSize;

    @Column(name = "file_url")
    private String fileUrl;

    @Column(name = "uploaded_by", nullable = false)
    private Long uploadedBy;

    @Column(name = "uploaded_at", nullable = false)
    private LocalDateTime uploadedAt;

    public void setFileName(String storedFileName) {
    }

    public Object getUploadedBy() {
    }

    public void setFileType(@Nullable String contentType) {
    }

    public void setFileSize(long size) {
    }

    public void setUploadedBy(Long userId) {
    }

    public void setUploadedAt(LocalDateTime now) {
    }

    public Long getId() {
    }

    public void setFileUrl(String s) {
    }

    public String getFileUrl() {
    }

    public String getFileType() {
    }

    // getters & setters
}
