package com.messageapp.api.modules.media.controller;

import com.messageapp.api.modules.media.dto.MediaUploadResponseDto;
import com.messageapp.api.modules.media.model.MediaFile;
import com.messageapp.api.modules.media.repository.MediaRepository;
import com.messageapp.api.modules.media.service.MediaService;
import com.messageapp.api.security.UserPrincipal;
import org.springframework.core.io.Resource;
import org.springframework.core.io.UrlResource;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

import java.nio.file.Path;
import java.nio.file.Paths;

@RestController
@RequestMapping("/api/media")
public class MediaController {

    private final MediaService mediaService;
    private final MediaRepository mediaRepository;

    public MediaController(MediaService mediaService,
                           MediaRepository mediaRepository) {
        this.mediaService = mediaService;
        this.mediaRepository = mediaRepository;
    }

    @PostMapping("/upload")
    public ResponseEntity<MediaUploadResponseDto> upload(
            @RequestParam("file") MultipartFile file,
            @AuthenticationPrincipal UserPrincipal user
    ) throws Exception {

        return ResponseEntity.ok(
                mediaService.upload(file, user.getId())
        );
    }

    @GetMapping("/{id}")
    public ResponseEntity<Resource> getMedia(
            @PathVariable Long id,
            @AuthenticationPrincipal UserPrincipal user
    ) throws Exception {

        MediaFile media = mediaRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("Media not found"));

        if (!media.getUploadedBy().equals(user.getId())) {
            throw new RuntimeException("Access denied");
        }

        Path path = Paths.get("uploads").resolve(media.getFileName());
        Resource resource = new UrlResource(path.toUri());

        return ResponseEntity.ok()
                .contentType(MediaType.parseMediaType(media.getFileType()))
                .body(resource);
    }
}
