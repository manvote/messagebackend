package com.messageapp.api.modules.media.dto;

public class MediaUploadResponseDto {

    private Long id;
    private String fileUrl;
    private String fileType;

    public MediaUploadResponseDto(Long id, String fileUrl, String fileType) {
        this.id = id;
        this.fileUrl = fileUrl;
        this.fileType = fileType;
    }

    public Long getId() {
        return id;
    }

    public String getFileUrl() {
        return fileUrl;
    }

    public String getFileType() {
        return fileType;
    }
}
