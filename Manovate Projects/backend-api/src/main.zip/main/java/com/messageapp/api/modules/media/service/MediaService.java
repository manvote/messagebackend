package com.messageapp.api.modules.media.service;

import com.messageapp.api.modules.media.dto.MediaUploadResponseDto;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;

public interface MediaService {

    MediaUploadResponseDto upload(MultipartFile file, Long userId) throws Throwable;
}
